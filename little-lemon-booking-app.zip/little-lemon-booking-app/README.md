# Little Lemon Booking App

This is a sample React app for booking tables at Little Lemon restaurant.