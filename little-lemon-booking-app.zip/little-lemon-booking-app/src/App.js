import React from 'react';
import BookingForm from './BookingForm';

function App() {
  return (
    <div>
      <h1>Little Lemon Booking</h1>
      <BookingForm />
    </div>
  );
}

export default App;